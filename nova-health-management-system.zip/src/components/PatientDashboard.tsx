import { useState } from 'react';
import { Patient, appointments, medicalRecords, invoices, doctors } from '../data';
import { Card, CardHeader, CardTitle, CardContent, Badge, Button } from './ui';
import { Calendar, FileText, CreditCard, UploadCloud, Download, FilePlus } from 'lucide-react';

export default function PatientDashboard({ user }: { user: Patient }) {
  const myAppointments = appointments.filter(a => a.patientId === user.id);
  const myRecords = medicalRecords.filter(r => r.patientId === user.id);
  const myInvoices = invoices.filter(i => i.patientId === user.id);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Welcome back, {user.firstName}</h1>
          <p className="text-slate-500 mt-1">Here is an overview of your medical journey.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <UploadCloud size={16} />
            Upload Document
          </Button>
          <Button className="gap-2">
            <Calendar size={16} />
            Book Appointment
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Appointments */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Calendar className="text-indigo-500" size={20} />
                Upcoming Appointments
              </CardTitle>
              <Button variant="ghost" className="text-sm">View All</Button>
            </CardHeader>
            <CardContent className="p-0">
              {myAppointments.length > 0 ? (
                <div className="divide-y divide-slate-100">
                  {myAppointments.map(app => {
                    const doctor = doctors.find(d => d.id === app.doctorId);
                    const isUpcoming = new Date(app.dateTime) > new Date();
                    return (
                      <div key={app.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold">
                            {new Date(app.dateTime).getDate()}
                          </div>
                          <div>
                            <p className="font-semibold text-slate-900">Dr. {doctor?.firstName} {doctor?.lastName}</p>
                            <p className="text-sm text-slate-500">{doctor?.specialization}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs font-medium text-slate-500">
                                {new Date(app.dateTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                              </span>
                              <Badge variant={app.status === 'SCHEDULED' ? 'info' : 'default'}>{app.status}</Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          {isUpcoming && <Button variant="outline" className="text-xs py-1.5 h-auto">Reschedule</Button>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center text-slate-500 flex flex-col items-center">
                  <Calendar size={32} className="text-slate-300 mb-3" />
                  <p>No upcoming appointments</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Medical Records & Results */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="text-emerald-500" size={20} />
                Recent Records & Results
              </CardTitle>
              <Button variant="ghost" className="text-sm">View Archive</Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {myRecords.map(record => {
                  const doctor = doctors.find(d => d.id === record.doctorId);
                  return (
                    <div key={record.id} className="border border-slate-200 rounded-lg p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-slate-900">{record.title}</h4>
                          <Badge variant={record.status === 'AUTHORIZED' ? 'success' : 'warning'}>
                            {record.status === 'AUTHORIZED' ? 'Available' : 'Pending Review'}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-500 mt-1 line-clamp-1">{record.description}</p>
                        <p className="text-xs text-slate-400 mt-2">
                          Ordered by Dr. {doctor?.lastName} • {new Date(record.date).toLocaleDateString()}
                        </p>
                      </div>
                      <Button 
                        variant="outline" 
                        className="gap-2 shrink-0 w-full sm:w-auto" 
                        disabled={record.status !== 'AUTHORIZED'}
                      >
                        <Download size={14} />
                        Download PDF
                      </Button>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

        </div>

        {/* Right Column */}
        <div className="space-y-8">
          
          {/* Billing & Payments */}
          <Card className="bg-slate-900 text-white border-0 shadow-lg relative overflow-hidden">
             {/* Decorative blob */}
            <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 rounded-full bg-indigo-500/20 blur-2xl"></div>
            
            <CardHeader className="border-0 bg-transparent pb-0 relative z-10">
              <CardTitle className="flex items-center gap-2 text-white">
                <CreditCard className="text-indigo-400" size={20} />
                Billing Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="mt-4">
                <p className="text-slate-400 text-sm">Total Outstanding</p>
                <p className="text-3xl font-bold mt-1 tracking-tight">
                  ${myInvoices.filter(i => i.status !== 'PAID').reduce((sum, inv) => sum + inv.amount, 0).toFixed(2)}
                </p>
              </div>
              
              <div className="mt-6 space-y-4">
                {myInvoices.filter(i => i.status !== 'PAID').map(inv => (
                  <div key={inv.id} className="bg-white/10 rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-sm">{inv.items[0]?.description}</p>
                        <p className="text-xs text-slate-400 mt-1">Due {new Date(inv.dueDate).toLocaleDateString()}</p>
                      </div>
                      <span className="font-semibold">${inv.amount.toFixed(2)}</span>
                    </div>
                    <Button className="w-full mt-4 bg-indigo-500 hover:bg-indigo-600 border-0 text-white py-1.5 h-auto text-sm shadow-none">
                      Pay Now
                    </Button>
                  </div>
                ))}
                {myInvoices.length === 0 && (
                  <p className="text-sm text-slate-400 text-center py-4">No outstanding invoices.</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Patient Details Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Profile Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">DOB</p>
                <p className="text-sm text-slate-900 mt-0.5">{new Date(user.dateOfBirth).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Blood Group</p>
                <p className="text-sm text-slate-900 mt-0.5">{user.bloodGroup || 'Not Specified'}</p>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Insurance</p>
                <p className="text-sm text-slate-900 mt-0.5">{user.insuranceProvider || 'Self Pay'}</p>
              </div>
              {user.allergies && user.allergies.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Allergies</p>
                  <div className="flex flex-wrap gap-2 mt-1.5">
                    {user.allergies.map(allergy => (
                      <span key={allergy} className="px-2 py-1 bg-red-50 text-red-700 text-xs rounded font-medium">
                        {allergy}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
        </div>
      </div>
    </div>
  );
}
