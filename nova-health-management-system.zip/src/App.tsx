import React, { useState } from 'react';
import Navigation from './components/Navigation';
import PatientDashboard from './components/PatientDashboard';
import DoctorDashboard from './components/DoctorDashboard';
import AdminDashboard from './components/AdminDashboard';
import { User, Patient, Doctor } from './types';
import { patients, doctors, mockCurrentUser } from './data';
import { Shield, Activity, Users } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
          <div className="mx-auto w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-4xl shadow-xl shadow-indigo-200">
            N
          </div>
          <h2 className="mt-6 text-3xl font-extrabold text-slate-900 tracking-tight">
            Nova<span className="text-indigo-600">Health</span>
          </h2>
          <p className="mt-2 text-sm text-slate-500">Select a portal to view the prototype.</p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
          <div className="bg-white py-8 px-4 shadow sm:rounded-xl sm:px-10 space-y-4 border border-slate-100">
            <button 
              onClick={() => handleLogin(patients[0])}
              className="w-full flex items-center justify-between px-6 py-4 border-2 border-slate-100 hover:border-blue-400 bg-white hover:bg-blue-50 rounded-xl transition-all group"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-100 text-blue-600 rounded-lg group-hover:bg-blue-200">
                  <Users size={24} />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-slate-900">Patient Portal</p>
                  <p className="text-xs text-slate-500">View records, book appointments</p>
                </div>
              </div>
            </button>

            <button 
              onClick={() => handleLogin(doctors[0])}
              className="w-full flex items-center justify-between px-6 py-4 border-2 border-slate-100 hover:border-emerald-400 bg-white hover:bg-emerald-50 rounded-xl transition-all group"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-emerald-100 text-emerald-600 rounded-lg group-hover:bg-emerald-200">
                  <Activity size={24} />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-slate-900">Medical Staff Portal</p>
                  <p className="text-xs text-slate-500">EHR, patient queue, clinical actions</p>
                </div>
              </div>
            </button>

            <button 
              onClick={() => handleLogin(mockCurrentUser)}
              className="w-full flex items-center justify-between px-6 py-4 border-2 border-slate-100 hover:border-purple-400 bg-white hover:bg-purple-50 rounded-xl transition-all group"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-purple-100 text-purple-600 rounded-lg group-hover:bg-purple-200">
                  <Shield size={24} />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-slate-900">Administrator Portal</p>
                  <p className="text-xs text-slate-500">System management, logs, billing</p>
                </div>
              </div>
            </button>
          </div>
          
          <div className="mt-8 text-center text-xs text-slate-400 max-w-sm mx-auto">
            This is a functional prototype. In production, this would securely authenticate via NextAuth, Auth0, or direct JWT with MFA enforced.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Navigation user={currentUser} onLogout={handleLogout} />
      
      <main>
        {currentUser.role === 'PATIENT' && <PatientDashboard user={currentUser as Patient} />}
        {currentUser.role === 'DOCTOR' && <DoctorDashboard user={currentUser as Doctor} />}
        {currentUser.role === 'ADMIN' && <AdminDashboard user={currentUser} />}
      </main>
    </div>
  );
}
