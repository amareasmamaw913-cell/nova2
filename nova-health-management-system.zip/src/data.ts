import { Patient, Doctor, Appointment, MedicalRecord, Invoice, AuditLog, User } from './types';

export const mockCurrentUser: User = {
  id: 'u1',
  email: 'system.admin@novahealth.com',
  role: 'ADMIN',
  firstName: 'System',
  lastName: 'Administrator',
  createdAt: '2025-01-01T00:00:00Z',
};

export const patients: Patient[] = [
  {
    id: 'p1',
    email: 'sarah.j@example.com',
    role: 'PATIENT',
    firstName: 'Sarah',
    lastName: 'Jenkins',
    dateOfBirth: '1985-04-12',
    bloodGroup: 'A+',
    allergies: ['Penicillin', 'Peanuts'],
    insuranceProvider: 'BlueCross',
    createdAt: '2025-02-15T00:00:00Z',
  },
  {
    id: 'p2',
    email: 'marcus.w@example.com',
    role: 'PATIENT',
    firstName: 'Marcus',
    lastName: 'Williams',
    dateOfBirth: '1992-11-03',
    bloodGroup: 'O-',
    insuranceProvider: 'Cigna',
    createdAt: '2025-03-01T00:00:00Z',
  }
];

export const doctors: Doctor[] = [
  {
    id: 'd1',
    email: 'dr.smith@novahealth.com',
    role: 'DOCTOR',
    firstName: 'Emily',
    lastName: 'Smith',
    specialization: 'Cardiology',
    department: 'Cardiovascular Center',
    licenseNumber: 'MD-12345',
    isAvailable: true,
    createdAt: '2024-11-20T00:00:00Z',
  },
  {
    id: 'd2',
    email: 'dr.choi@novahealth.com',
    role: 'DOCTOR',
    firstName: 'Michael',
    lastName: 'Choi',
    specialization: 'General Practice',
    department: 'Primary Care',
    licenseNumber: 'MD-98765',
    isAvailable: true,
    createdAt: '2024-10-15T00:00:00Z',
  }
];

export const appointments: Appointment[] = [
  {
    id: 'a1',
    patientId: 'p1',
    doctorId: 'd1',
    dateTime: '2026-06-16T09:00:00Z',
    status: 'SCHEDULED',
    type: 'IN_PERSON',
    notes: 'Routine ECG checkup',
  },
  {
    id: 'a2',
    patientId: 'p2',
    doctorId: 'd2',
    dateTime: '2026-06-16T11:30:00Z',
    status: 'CHECKED_IN',
    type: 'IN_PERSON',
    notes: 'Fever and mild cough',
  }
];

export const medicalRecords: MedicalRecord[] = [
  {
    id: 'mr1',
    patientId: 'p1',
    doctorId: 'd1',
    type: 'LAB_RESULT',
    title: 'Complete Blood Count',
    description: 'All levels within normal ranges except slight elevation in LDL cholesterol.',
    date: '2026-05-10T00:00:00Z',
    status: 'AUTHORIZED',
  },
  {
    id: 'mr2',
    patientId: 'p2',
    doctorId: 'd2',
    type: 'LAB_RESULT',
    title: 'Strep Throat Culture',
    description: 'Pending authorization from attending physician.',
    date: '2026-06-15T00:00:00Z',
    status: 'PENDING_AUTHORIZATION',
  }
];

export const invoices: Invoice[] = [
  {
    id: 'inv1',
    patientId: 'p1',
    amount: 150.00,
    dateIssued: '2026-05-10T00:00:00Z',
    dueDate: '2026-06-10T00:00:00Z',
    status: 'OVERDUE',
    items: [{ description: 'Cardiology Consultation', cost: 150.00 }],
  },
  {
    id: 'inv2',
    patientId: 'p2',
    amount: 45.00,
    dateIssued: '2026-06-15T00:00:00Z',
    dueDate: '2026-07-15T00:00:00Z',
    status: 'UNPAID',
    items: [{ description: 'Co-pay General Practice', cost: 45.00 }],
  }
];

export const auditLogs: AuditLog[] = [
  {
    id: 'log1',
    userId: 'd1',
    action: 'ACCESSED_PATIENT_RECORD',
    resourceId: 'p1',
    timestamp: '2026-06-15T08:24:00Z',
    ipAddress: '192.168.1.104',
  },
  {
    id: 'log2',
    userId: 'u1',
    action: 'UPDATED_ROLE_PERMISSIONS',
    resourceId: 'd2',
    timestamp: '2026-06-15T14:10:00Z',
    ipAddress: '10.0.0.5',
  }
];
