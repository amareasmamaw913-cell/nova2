// Database Entities (Simulated DDL Equivalent)

export type Role = 'PATIENT' | 'DOCTOR' | 'ADMIN';

export interface User {
  id: string;
  email: string;
  role: Role;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  createdAt: string;
  lastLogin?: string;
}

export interface Patient extends User {
  role: 'PATIENT';
  dateOfBirth: string;
  bloodGroup?: string;
  allergies?: string[];
  insuranceProvider?: string;
  insurancePolicyNumber?: string;
}

export interface Doctor extends User {
  role: 'DOCTOR';
  specialization: string;
  department: string;
  licenseNumber: string;
  isAvailable: boolean;
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  dateTime: string;
  status: 'SCHEDULED' | 'CHECKED_IN' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  type: 'IN_PERSON' | 'TELEHEALTH';
  notes?: string;
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorId: string;
  type: 'DIAGNOSIS' | 'PRESCRIPTION' | 'LAB_RESULT' | 'Clinical_Note';
  title: string;
  description: string;
  date: string;
  attachments?: string[];
  status: 'PENDING_AUTHORIZATION' | 'AUTHORIZED' | 'ARCHIVED';
}

export interface Invoice {
  id: string;
  patientId: string;
  amount: number;
  dateIssued: string;
  dueDate: string;
  status: 'PAID' | 'UNPAID' | 'OVERDUE' | 'PARTIALLY_PAID';
  items: { description: string; cost: number }[];
}

export interface AuditLog {
  id: string;
  userId: string;
  action: string;
  resourceId?: string;
  timestamp: string;
  ipAddress: string;
}
