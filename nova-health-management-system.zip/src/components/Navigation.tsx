import { LogOut, User as UserIcon } from 'lucide-react';
import { User, Role } from '../types';

interface NavigationProps {
  user: User | null;
  onLogout: () => void;
}

export default function Navigation({ user, onLogout }: NavigationProps) {
  if (!user) return null;

  const roleColors = {
    PATIENT: 'bg-blue-100 text-blue-700 border-blue-200',
    DOCTOR: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    ADMIN: 'bg-purple-100 text-purple-700 border-purple-200',
  };

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center gap-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
                N
              </div>
              <span className="font-semibold text-xl tracking-tight text-slate-900">
                Nova<span className="text-indigo-600">Health</span>
              </span>
            </div>
            <div className="ml-8 flex space-x-4">
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${roleColors[user.role]}`}>
                {user.role} PORTAL
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 pr-4 border-r border-slate-200">
              <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 overflow-hidden">
                {user.avatarUrl ? (
                  <img src={user.avatarUrl} alt={user.firstName} className="w-full h-full object-cover" />
                ) : (
                  <UserIcon size={16} />
                )}
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-medium text-slate-700 leading-none">
                  {user.role === 'DOCTOR' ? 'Dr. ' : ''}{user.firstName} {user.lastName}
                </span>
                <span className="text-xs text-slate-500 mt-1">{user.email}</span>
              </div>
            </div>
            <button 
              onClick={onLogout}
              className="text-slate-500 hover:text-slate-700 p-2 rounded-md hover:bg-slate-100 transition-colors flex items-center gap-2 text-sm font-medium"
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
