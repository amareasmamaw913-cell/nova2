import { User, invoices, auditLogs, patients, doctors } from '../data';
import { Card, CardHeader, CardTitle, CardContent, Badge, Button } from './ui';
import { DollarSign, UserCog, ShieldAlert, BarChart3, Users as UsersIcon, ChevronRight } from 'lucide-react';

export default function AdminDashboard({ user }: { user: User }) {
  const totalRevenue = invoices.reduce((acc, inv) => acc + inv.amount, 0);
  const totalOutstanding = invoices.filter(i => i.status !== 'PAID').reduce((acc, inv) => acc + inv.amount, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">System Administration</h1>
          <p className="text-slate-500 mt-1">Enterprise management console.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 border-slate-300 text-slate-700">
            <BarChart3 size={16} />
            Generate Reports
          </Button>
          <Button className="gap-2 bg-slate-900 hover:bg-black">
            <UserCog size={16} />
            Add New User
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-4 rounded-full bg-emerald-100 text-emerald-700">
              <DollarSign size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">Gross Revenue (MTD)</p>
              <p className="text-2xl font-bold text-slate-900">${totalRevenue.toFixed(2)}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-4 rounded-full bg-amber-100 text-amber-700">
              <DollarSign size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">Total Outstanding</p>
              <p className="text-2xl font-bold text-slate-900">${totalOutstanding.toFixed(2)}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-4 rounded-full bg-blue-100 text-blue-700">
              <UsersIcon size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">Active Medical Staff</p>
              <p className="text-2xl font-bold text-slate-900">{doctors.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* User Management */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <UserCog className="text-indigo-500" size={20} />
              Recent Staff Activity
            </CardTitle>
            <Button variant="ghost" className="text-sm">Manage Staff</Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-slate-100">
              {doctors.map(doc => (
                <div key={doc.id} className="p-4 sm:p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                      {doc.firstName[0]}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-900">Dr. {doc.firstName} {doc.lastName}</p>
                      <p className="text-sm text-slate-500">{doc.specialization} • {doc.department}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={doc.isAvailable ? 'success' : 'default'}>
                      {doc.isAvailable ? 'Active' : 'Offline'}
                    </Badge>
                    <button className="text-slate-400 hover:text-indigo-600 transition-colors">
                      <ChevronRight size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Audit Logs */}
        <Card className="border-indigo-100">
          <CardHeader className="bg-slate-50/50 border-b-slate-100 flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-slate-800">
              <ShieldAlert className="text-slate-500" size={20} />
              System Audit Logs
            </CardTitle>
            <Badge variant="warning">Compliance Mode</Badge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-slate-100">
              {auditLogs.map(log => (
                <div key={log.id} className="p-4 sm:p-5 hover:bg-slate-50 transition-colors">
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {log.action}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {new Date(log.timestamp).toISOString().replace('T', ' ').substring(0, 19)}
                    </span>
                  </div>
                  <div className="mt-2 text-sm text-slate-600 flex flex-wrap gap-x-4 gap-y-1">
                    <p>User ID: <span className="font-mono text-slate-800 bg-slate-100 px-1 rounded">{log.userId}</span></p>
                    {log.resourceId && (
                      <p>Resource: <span className="font-mono text-slate-800 bg-slate-100 px-1 rounded">{log.resourceId}</span></p>
                    )}
                    <p>IP: <span className="font-mono text-slate-800">{log.ipAddress}</span></p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
