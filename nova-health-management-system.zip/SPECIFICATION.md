# NovaHealth Backend Specification

This document satisfies the requirement for the backend API and architecture specification for the Hospital Management System (HMS), tailored for the desired tech stack.

## Tech Stack Overview
- **Backend framework**: Node.js with NestJS (or Express) / Python FastAPI
- **Database**: PostgreSQL (Relational, ACID compliant) + Redis (Caching & Rate Limiting)
- **Object Storage**: AWS S3 (AES-256 encrypted at rest) for medical files and PDFs.
- **Auth**: JWT stored in HttpOnly cookies, enforced MFA.

## Database Schema / ERD (Prisma DDL format)

```prisma
// This schema represents the SQL relational structure

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

enum Role {
  PATIENT
  DOCTOR
  ADMIN
}

model User {
  id        String   @id @default(uuid())
  email     String   @unique
  password  String   // bcrypt hashed
  firstName String
  lastName  String
  role      Role
  mfaSecret String?  // TOTP secret
  mfaEnabled Boolean @default(false)
  createdAt DateTime @default(now())

  // Relations
  patientProfile PatientProfile?
  doctorProfile  DoctorProfile?
  auditLogs      AuditLog[]

  @@map("users")
}

model PatientProfile {
  id             String   @id @default(uuid())
  userId         String   @unique
  user           User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  dateOfBirth    DateTime
  bloodGroup     String?
  allergies      String[] // Array of strings in Postgres
  insurancePrv   String?
  insuranceNum   String?

  appointments   Appointment[]
  medicalRecords MedicalRecord[]
  invoices       Invoice[]

  @@map("patient_profiles")
}

model DoctorProfile {
  id             String   @id @default(uuid())
  userId         String   @unique
  user           User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  specialization String
  department     String
  licenseNumber  String   @unique
  isAvailable    Boolean  @default(true)

  appointments   Appointment[]
  authorizedRecords MedicalRecord[]

  @@map("doctor_profiles")
}

model Appointment {
  id          String   @id @default(uuid())
  patientId   String
  patient     PatientProfile @relation(fields: [patientId], references: [id])
  doctorId    String
  doctor      DoctorProfile  @relation(fields: [doctorId], references: [id])
  dateTime    DateTime
  status      String   // SCHEDULED, CHECKED_IN, IN_PROGRESS, COMPLETED, CANCELLED
  type        String   // IN_PERSON, TELEHEALTH
  notes       String?  @db.Text

  @@map("appointments")
}

model MedicalRecord {
  id          String   @id @default(uuid())
  patientId   String
  patient     PatientProfile @relation(fields: [patientId], references: [id])
  doctorId    String
  doctor      DoctorProfile  @relation(fields: [doctorId], references: [id])
  type        String   // DIAGNOSIS, PRESCRIPTION, LAB_RESULT
  title       String
  description String   @db.Text
  date        DateTime @default(now())
  status      String   // PENDING_AUTHORIZATION, AUTHORIZED
  s3ObjectKeys String[] // Links to encrypted S3 files

  @@map("medical_records")
}

model Invoice {
  id          String   @id @default(uuid())
  patientId   String
  patient     PatientProfile @relation(fields: [patientId], references: [id])
  amount      Float
  dateIssued  DateTime @default(now())
  dueDate     DateTime
  status      String   // PAID, UNPAID, OVERDUE

  @@map("invoices")
}

model AuditLog {
  id          String   @id @default(uuid())
  userId      String
  user        User     @relation(fields: [userId], references: [id])
  action      String
  resourceId  String?
  ipAddress   String
  timestamp   DateTime @default(now())

  @@map("audit_logs")
}
```

## API Endpoint Specifications

### 1. Authentication (Protected by Rate Limiting)
- **`POST /api/v1/auth/login`**
  - **Body Payload**: `{ "email": "user@nova.com", "password": "...", "mfaToken": "123456" }`
  - **Response**: `200 OK` (Sets Secure, HttpOnly cookie with JWT). Returns user profile.
- **`POST /api/v1/auth/logout`**
  - **Response**: `200 OK` (Clears JWT cookie).

### 2. Patient Endpoints (Requires `Role=PATIENT`)
- **`GET /api/v1/patients/me/records`**
  - **Response**: Returns array of authorized `MedicalRecord` objects natively linked to the authenticated JWT context. Does NOT accept target `userId` in URL to prevent Horizontal Privilege Escalation.
- **`POST /api/v1/patients/me/documents`**
  - **Action**: Uploads multipart form data. Scans for malware contextually then saves encrypted object to S3 bucket.
  - **Response**: `201 Created` with secure S3 reference ID.
- **`POST /api/v1/payments/charge`**
  - **Body Payload**: `{ "invoiceId": "uuid", "paymentMethodId": "stripe_token" }`
  - **Response**: `200 OK` with generated receipt URL on success.

### 3. Doctor Endpoints (Requires `Role=DOCTOR`)
- **`GET /api/v1/doctors/me/queue?date=YYYY-MM-DD`**
  - **Response**: Returns list of `Appointment` objects merged with brief patient summaries for the specified day.
- **`GET /api/v1/patients/{patientId}`**
  - **Access Control**: System checks if the requesting doctor has a scheduled appointment or active relation to the patient. Throws 403 otherwise.
- **`POST /api/v1/records/{recordId}/authorize`**
  - **Action**: Electronically signs a pending lab result or prescription.
  - **Response**: Updates record status to `AUTHORIZED`.

### 4. Admin Endpoints (Requires `Role=ADMIN` + strict IP geofencing)
- **`GET /api/v1/admin/audit-logs`**
  - **Params**: `?userId=...&action=ACCESSED_PATIENT_RECORD`
  - **Response**: Paginated array of system-wide access events.
- **`POST /api/v1/admin/users`**
  - **Body Payload**: Profile definitions specifying system roles, permissions, and initial reset tokens.

## Security Constraints Implemented
- **Horizontal Privilege Escalation Protection**: All standard data access explicitly utilizes the JWT subject ID (`sub`). `userId` URL parameters are strictly discarded for Patients.
- **Data At Rest**: S3 configured with AWS KMS managed encryption keys (SSE-KMS, AES-256). PostgreSQL instance encrypted at EBS volume level.
- **Data In Transit**: Required TLS 1.3 for all load balancers. Application layer rejects non-HTTPS traffic.
