import { useState } from 'react';
import { Doctor, appointments, patients, medicalRecords } from '../data';
import { Card, CardHeader, CardTitle, CardContent, Badge, Button } from './ui';
import { Users, FileSignature, Activity, Search, Clock, PlusCircle } from 'lucide-react';

export default function DoctorDashboard({ user }: { user: Doctor }) {
  const myQueue = appointments.filter(a => a.doctorId === user.id && new Date(a.dateTime).toDateString() === new Date('2026-06-16').toDateString()); // Using mock date
  const pendingAuthorizations = medicalRecords.filter(r => r.doctorId === user.id && r.status === 'PENDING_AUTHORIZATION');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Dr. {user.lastName}'s Workspace</h1>
          <p className="text-slate-500 mt-1">{user.department} • {user.specialization}</p>
        </div>
        <div className="flex bg-white rounded-lg border border-slate-200 overflow-hidden shrink-0 w-full md:w-auto">
          <div className="pl-3 py-2 flex items-center text-slate-400">
            <Search size={18} />
          </div>
          <input 
            type="text" 
            placeholder="Search patient by name or ID..." 
            className="w-full md:w-64 px-3 py-2 text-sm focus:outline-none"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Column - Queue */}
        <div className="lg:col-span-2 space-y-8">
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between bg-slate-50">
              <CardTitle className="flex items-center gap-2">
                <Users className="text-indigo-500" size={20} />
                Today's Patient Queue
              </CardTitle>
              <Badge variant="info">{myQueue.length} Patients</Badge>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-slate-100">
                {myQueue.map(app => {
                  const patient = patients.find(p => p.id === app.patientId);
                  if (!patient) return null;
                  
                  return (
                    <div key={app.id} className="p-4 sm:p-6 hover:bg-slate-50 transition-colors group">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6 w-full">
                          <div className="flex flex-col sm:flex-row sm:items-center gap-4 w-full">
                            <div className="text-sm font-semibold text-slate-700 whitespace-nowrap min-w-[70px]">
                              {new Date(app.dateTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </div>
                            
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold shrink-0">
                                {patient.firstName[0]}{patient.lastName[0]}
                              </div>
                              <div>
                                <p className="font-bold text-slate-900">{patient.lastName}, {patient.firstName}</p>
                                <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                                  <span>ID: {patient.id}</span>
                                  <span>•</span>
                                  <span>{Math.floor((new Date().getTime() - new Date(patient.dateOfBirth).getTime()) / 31557600000)} yrs</span>
                                  <span>•</span>
                                  <span className="font-semibold text-red-600">{patient.bloodGroup}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2 mt-4 sm:mt-0 justify-end w-full sm:w-auto">
                          <Badge variant={app.status === 'CHECKED_IN' ? 'success' : 'default'}>
                            {app.status.replace('_', ' ')}
                          </Badge>
                          <Button variant="outline" className="opacity-0 group-hover:opacity-100 transition-opacity">
                            Open EHR
                          </Button>
                        </div>
                      </div>
                      
                      {app.notes && (
                        <div className="mt-4 sm:pl-28 text-sm text-slate-600 flex items-start gap-2 bg-amber-50/50 p-3 rounded-lg border border-amber-100">
                           <Activity size={16} className="text-amber-500 mt-0.5 shrink-0" />
                           <span>Reason: {app.notes}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
                {myQueue.length === 0 && (
                  <div className="p-8 text-center text-slate-500">
                    <p>No appointments today.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
        </div>

        {/* Right Column - Actions & Alerts */}
        <div className="space-y-8">
          
          <Card className="border-rose-200 shadow-sm bg-rose-50/20">
            <CardHeader className="bg-transparent border-rose-100 pb-2">
              <CardTitle className="flex items-center gap-2 text-rose-800 text-base">
                <FileSignature size={18} className="text-rose-600" />
                Pending Authorizations
                {pendingAuthorizations.length > 0 && (
                  <span className="bg-rose-600 text-white text-xs px-2 py-0.5 rounded-full ml-auto">
                    {pendingAuthorizations.length}
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {pendingAuthorizations.length > 0 ? (
                <div className="space-y-4">
                  {pendingAuthorizations.map(record => {
                    const patient = patients.find(p => p.id === record.patientId);
                    return (
                      <div key={record.id} className="bg-white rounded-lg p-4 border border-rose-100 shadow-sm">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-semibold text-sm text-slate-900">{record.title}</p>
                            <p className="text-xs text-slate-500 mt-1">Patient: {patient?.firstName} {patient?.lastName}</p>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-4">
                          <Button className="w-full bg-rose-600 hover:bg-rose-700 text-white py-1.5 h-auto text-xs border-0">
                            Review & Sign
                          </Button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              ) : (
                <div className="text-center py-4 text-slate-500 text-sm">
                  All caught up! No pending results to authorize.
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base text-slate-700">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 p-4">
              <Button variant="outline" className="w-full justify-start gap-3 h-12 text-slate-700 hover:text-indigo-700 hover:bg-indigo-50 border-slate-200">
                <PlusCircle size={18} className="text-indigo-500" />
                Write e-Prescription
              </Button>
              <Button variant="outline" className="w-full justify-start gap-3 h-12 text-slate-700 hover:text-emerald-700 hover:bg-emerald-50 border-slate-200">
                <Activity size={18} className="text-emerald-500" />
                Order Lab Test
              </Button>
              <Button variant="outline" className="w-full justify-start gap-3 h-12 text-slate-700 hover:text-amber-700 hover:bg-amber-50 border-slate-200">
                <Clock size={18} className="text-amber-500" />
                View On-Call Schedule
              </Button>
            </CardContent>
          </Card>

        </div>
      </div>
    </div>
  );
}
